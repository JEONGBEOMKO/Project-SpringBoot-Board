package com.spring.projectboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
